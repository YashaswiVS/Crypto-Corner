 <footer>
			<div class="container-fluid">
				<p class="copyright">&copy; 2021 Crypto-Corner</p>
			</div>
		</footer>
