

  
<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						<li><a href="index.php" class="active"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
						
						<li><a href="vcl.php" class=""><i class="fa fa-users"></i> <span>View Clients</span></a></li>

            			<li><a href="viewcfiles.php" class=""><i class="fa fa-folder"></i> <span>View Files</span></a></li>
						
						

						<li><a href="aud.php" class=""><i class="fa fa-file"></i> <span>Audited Files</span></a></li>
						<li>
							<a href="#msg" data-toggle="collapse" class="collapsed"><i class="fa fa-envelope"></i> <span>Messages  </span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="msg" class="collapse ">
								<ul class="nav">
									<!-- <li><a href="sendmessges.php" class="">Send Message</a></li> -->
									<li><a href="msgfromadmin.php" class="">Admin Messages </a></li>
									<li><a href="msgfromclient.php" class="">Client Messages</a></li>
								</ul>
							</div>
						</li>
					
						<li><a href="profile.php"><i class="fa fa-user"></i> <span>Profile</span></a></li>

						<li><a href="../../Controller/logout.php" class=""><i class="fa fa-sign-out"></i> <span>Logout</span></a></li>
					</ul>
				</nav>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->