        <footer>
			<div class="container-fluid">
				<p class="copyright">&copy; 2021 Crypto-Corner by Yashaswi Sparsha Swasthik</p>
			</div>
		</footer>

		